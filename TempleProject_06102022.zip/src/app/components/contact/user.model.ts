export class UserModel{
    firstName:string = '';
    lastName:string = '';
    email: string = '';
    phoneNumber:string = '';
    message : string = '';
}