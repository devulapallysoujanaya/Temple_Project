import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angels',
  templateUrl: './angels.component.html',
  styleUrls: ['./angels.component.css']
})
export class AngelsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
