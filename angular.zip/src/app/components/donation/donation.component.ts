import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donation',
  templateUrl: './donation.component.html',
  styleUrls: ['./donation.component.css'],
})
export class DonationComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  cards: any[] = [
    {
      img: '/assets/project_images/ban.webp',
      title: 'Donate Ngos',
      desc: 'Some quick example text to build on the card title and make up the',
          

      raised: 'Raised: $ 54000',
      goal: 'Goal: $80000',
    },
    {
      img: '/assets/project_images/poo.jpg',
      title: 'Donate Ngos',
      desc: 'Some quick example text to build on the card title and make up the',
          

      raised: 'Raised: $ 54000',
      goal: 'Goal: $80000',
    },
    {
      img: '/assets/project_images/temple_art.webp',
      title: 'Donate Ngos',
      desc: 'Some quick example text to build on the card title and make up the',
          

      raised: 'Raised: $ 54000',
      goal: 'Goal: $80000',
    },
  ];
}
