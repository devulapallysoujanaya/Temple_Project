import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css'],
})
export class BlogComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  cards: any[] = [
    {
      img: '/assets/project_images/agoo.jpg',
      date: 'sep 29, 2022',
      desc: 'Temple companies are being so tarnsparent with their work   ',
      name: 'Amie Bill',
    },
    {
      img: '/assets/project_images/hart.jpg',
      date: 'Aug 3, 2022',
      desc: 'Temple companies are being so tarnsparent with their work   ',
      name: 'Rajyasri',
    },
    {
      img: '/assets/project_images/hart.jpg',
      date: 'nov 2, 2022',
      desc: 'Temple companies are being so tarnsparent with their work   ',
      name: 'Durga',
    },
  ];
}
