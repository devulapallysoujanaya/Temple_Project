import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BlogComponent } from './components/blog/blog.component';
import { DonationComponent } from './components/donation/donation.component';
import { EducationComponent } from './components/education/education.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { ServiceComponent } from './components/service/service.component';
import { SliderComponent } from './components/slider/slider.component';

const routes: Routes = [
  {path:'', component:SliderComponent},
  {path:'events', component:ServiceComponent},
 

  {path:'donations', component:DonationComponent},
 

 {path:'home', component:SliderComponent},
{path:'puja', component:PortfolioComponent},
  {path:'pages', component:BlogComponent},
  {path:'holis', component:EducationComponent},
 

 

 

 


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
