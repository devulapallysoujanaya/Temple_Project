import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BlogComponent } from './components/blog/blog.component';
import { ContactComponent } from './components/contact/contact.component';
import { DonationSuccessRateComponent } from './components/donation-success-rate/donation-success-rate.component';
import { DonationComponent } from './components/donation/donation.component';
import { EducationComponent } from './components/education/education.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { ServiceComponent } from './components/service/service.component';
import { SliderComponent } from './components/slider/slider.component';
import { TestimonalsComponent } from './components/testimonals/testimonals.component';

const routes: Routes = [
  { path: '', component: SliderComponent },
  { path: 'events-1', component: ServiceComponent },

  { path: 'donations', component: DonationComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'events', component: DonationSuccessRateComponent },
  { path: 'testimonals', component: TestimonalsComponent },

  { path: 'home', component: SliderComponent },
  { path: 'puja', component: PortfolioComponent },
  { path: 'pages', component: BlogComponent },
  { path: 'services', component: EducationComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
