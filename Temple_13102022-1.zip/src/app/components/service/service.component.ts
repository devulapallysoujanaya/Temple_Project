import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.css'],
})
export class ServiceComponent implements OnInit {
  
  constructor() {}

  ngOnInit(): void {}
  cards: any[] = [
    {
      img: '/assets/project_images/temple.png',
      title: 'About Temple',
      desc: 'Temple is the place where Hindu Worship consectetur adipisicing elit,sed do',
      backgroundColor:'card_1'
    
      
    },
    {
      img: '/assets/project_images/pan.png',
      title: 'Our Pandits',
      desc: 'Temple is the place where Hindu Worship consectetur adipisicing elit,sed do',
      backgroundColor:'card_2'
    
    },
    {
      img: '/assets/project_images/temple.png',
      title: 'Prayers',
      desc: 'Temple is the place where Hindu Worship consectetur adipisicing elit,sed do',
      backgroundColor:'card_3'
      
    },
  ];
}
