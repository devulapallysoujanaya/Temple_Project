import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css'],
})
export class PortfolioComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
  cards: any[] = [
    {
      img: '/assets/project_images/portfolio_3.jpeg',
      festival: 'Deevali festival',
    },
    {
      img: '/assets/project_images/pray.jpg',
      festival: 'Holi festival',
    },
    {
      img: '/assets/project_images/portfolio_3.jpeg',
      festival: 'Sankranti festival',
    },
    {
      img: '/assets/project_images/portfolio_4.jpeg',
      festival: 'holi festival',
    },
 
    {
      img: '/assets/project_images/pray.jpg',
      festival: 'Deevali festival',
    },
 
    {
      img: '/assets/project_images/portfolio_4.jpeg',
      festival: 'Deevali festival',
    },
    {
      img: '/assets/project_images/portfolio_3.jpeg',
      festival: 'Deevali festival',
    },
 
    {
      img: '/assets/project_images/pray.jpg',
      festival: 'Deevali festival',
    },
 
 
 
 
  ];
}
