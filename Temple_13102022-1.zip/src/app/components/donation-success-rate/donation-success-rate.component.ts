import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donation-success-rate',
  templateUrl: './donation-success-rate.component.html',
  styleUrls: ['./donation-success-rate.component.css']
})
export class DonationSuccessRateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
