import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DonationSuccessRateComponent } from './donation-success-rate.component';

describe('DonationSuccessRateComponent', () => {
  let component: DonationSuccessRateComponent;
  let fixture: ComponentFixture<DonationSuccessRateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DonationSuccessRateComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DonationSuccessRateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
