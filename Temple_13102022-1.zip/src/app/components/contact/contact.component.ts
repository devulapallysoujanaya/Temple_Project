import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, NgForm, Validators } from '@angular/forms';
import { ApiService } from 'src/app/services/api.service';
import { UserModel } from './user.model';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
})
export class ContactComponent implements OnInit {
  userForm!: FormGroup;
  userObj: UserModel = new UserModel();
  showsuccessMessage = false;
  showFailureMessage = false;

  constructor(private formbuilder: FormBuilder, private api: ApiService) {}

  ngOnInit(): void {
    this.userForm = this.formbuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', Validators.required],
      message: ['', Validators.required],
    });
  }
  postUserDetails() {
    this.userObj.firstName = this.userForm.value.firstName;
    this.userObj.lastName = this.userForm.value.lastName;
    this.userObj.email = this.userForm.value.email;
    this.userObj.phoneNumber = this.userForm.value.phoneNumber;
    this.userObj.message = this.userForm.value.message;

    this.api.postUser(this.userObj).subscribe(
      (res) => {
        console.log(res);

        this.showsuccessMessage = true;
      },
      (err) => {
        this.showFailureMessage = true;
      }
    );
    this.userForm.reset();
  }
}
